
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { generateScript, analyzeScript, generateImageForScene, generateTTS } from './services/geminiService';
import { Scene, StoryState, GenerationStep, VoicePersona, VoiceGender } from './types';
import { 
  SparklesIcon, PlayIcon, PauseIcon, 
  ArrowDownTrayIcon, ArrowPathIcon, UserIcon, ClockIcon, 
  BanknotesIcon, HandRaisedIcon, VideoCameraIcon,
  InformationCircleIcon, CheckCircleIcon, DocumentTextIcon,
  ChevronRightIcon, MusicalNoteIcon
} from '@heroicons/react/24/outline';
import { motion, AnimatePresence } from 'framer-motion';

const INITIAL_STEPS: GenerationStep[] = [
  { id: 'prep', label: 'Vocal Master Engine', status: 'idle' },
  { id: 'analyze', label: 'Cinematic Storyboarding', status: 'idle' },
  { id: 'visuals', label: 'Art Asset Rendering', status: 'idle' },
  { id: 'finalize', label: 'Production Master', status: 'idle' },
];

const BG_MUSIC_URL = "https://cdn.pixabay.com/audio/2022/01/18/audio_d0a13f69d2.mp3"; // Motivational cinematic track

const App: React.FC = () => {
  const [state, setState] = useState<StoryState>({
    topic: '',
    scriptText: '',
    isGeneratingScript: false,
    appStage: 'input',
    audioFile: null,
    characterFile: null,
    voicePersona: 'zak',
    voiceGender: 'male',
    voiceSpeed: 1.0,
    zakMode: true,
    scenes: [],
    isProcessing: false,
    isRendering: false,
    progress: 0,
    renderProgress: 0,
    message: 'Awaiting Topic...',
    steps: INITIAL_STEPS
  });

  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [eta, setEta] = useState<number | null>(null);
  
  const audioRef = useRef<HTMLAudioElement>(null);
  const musicRef = useRef<HTMLAudioElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const musicSourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const imageCache = useRef<Map<string, HTMLImageElement>>(new Map());
  const handImageRef = useRef<HTMLImageElement | null>(null);
  const timerRef = useRef<number | null>(null);
  const cameraRef = useRef({ x: 0, y: 0, z: 1 });

  useEffect(() => {
    const hand = new Image();
    hand.crossOrigin = "anonymous";
    hand.src = "https://i.ibb.co/L5w2RST/sketch-hand.png";
    hand.onload = () => handImageRef.current = hand;
  }, []);

  const updateStepStatus = (id: string, status: GenerationStep['status']) => {
    setState(s => ({
      ...s,
      steps: s.steps.map(step => step.id === id ? { ...step, status } : step)
    }));
  };

  const handleGenerateScript = async () => {
    if (!state.topic) return;
    setState(s => ({ ...s, isGeneratingScript: true }));
    try {
      const script = await generateScript(state.topic);
      setState(s => ({ ...s, scriptText: script, isGeneratingScript: false, appStage: 'script' }));
    } catch (e) {
      console.error(e);
      setState(s => ({ ...s, isGeneratingScript: false }));
    }
  };

  const handleStartProduction = async () => {
    setState(s => ({ ...s, appStage: 'production', isProcessing: true, message: 'Warming Engines...', steps: INITIAL_STEPS, scenes: [] }));
    setElapsedTime(0);
    timerRef.current = window.setInterval(() => setElapsedTime(p => p + 1), 1000);

    try {
      updateStepStatus('prep', 'loading');
      const tts = await generateTTS(state.scriptText, state.voiceGender, state.voiceSpeed, state.zakMode);
      
      const binary = atob(tts.base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const buffer = new ArrayBuffer(44 + bytes.length);
      const view = new DataView(buffer);
      const writeString = (o: number, s: string) => { for (let i = 0; i < s.length; i++) view.setUint8(o + i, s.charCodeAt(i)); };
      writeString(0, 'RIFF'); view.setUint32(4, 36 + bytes.length, true); writeString(8, 'WAVE');
      writeString(12, 'fmt '); view.setUint32(16, 16, true); view.setUint16(20, 1, true);
      view.setUint16(22, 1, true); view.setUint32(24, tts.sampleRate, true);
      view.setUint32(28, tts.sampleRate * 2, true); view.setUint16(32, 2, true); view.setUint16(34, 16, true);
      writeString(36, 'data'); view.setUint32(40, bytes.length, true);
      new Uint8Array(buffer, 44).set(bytes);
      const audioUrl = URL.createObjectURL(new Blob([buffer], { type: 'audio/wav' }));
      if (audioRef.current) audioRef.current.src = audioUrl;
      const tempAudio = new Audio(audioUrl);
      await new Promise(r => tempAudio.onloadedmetadata = r);
      const duration = tempAudio.duration;

      updateStepStatus('prep', 'complete');
      updateStepStatus('analyze', 'loading');
      const scenes = await analyzeScript(state.scriptText, undefined, undefined, duration, state.zakMode);
      setEta(Math.round(scenes.length * 5 + 5));
      updateStepStatus('analyze', 'complete');
      updateStepStatus('visuals', 'loading');

      const finalScenes = [...scenes];
      let completed = 0;
      for (let i = 0; i < scenes.length; i += 2) {
        const batch = scenes.slice(i, i + 2);
        await Promise.all(batch.map(async (scene) => {
          try {
            const url = await generateImageForScene(scene.prompt, undefined, scene.style);
            const img = new Image(); 
            img.crossOrigin = "anonymous"; img.src = url;
            await new Promise(r => img.onload = r); 
            imageCache.current.set(url, img);
            const idx = finalScenes.findIndex(fs => fs.id === scene.id);
            finalScenes[idx] = { ...scene, assetUrl: url };
          } catch (e) { console.error(e); }
          completed++;
          setState(s => ({ ...s, progress: 20 + Math.round((completed/scenes.length)*75) }));
        }));
      }

      setState(s => ({ ...s, scenes: finalScenes, isProcessing: false }));
      updateStepStatus('visuals', 'complete');
      updateStepStatus('finalize', 'complete');
      if (timerRef.current) clearInterval(timerRef.current);
    } catch (err) {
      console.error(err);
      setState(s => ({ ...s, isProcessing: false, message: 'Critical Fault' }));
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const activeScene = useMemo(() => {
    if (state.scenes.length === 0) return null;
    const scene = state.scenes.find(s => currentTime >= s.startTime && currentTime <= s.endTime);
    if (!scene && currentTime > state.scenes[state.scenes.length - 1].endTime) return state.scenes[state.scenes.length - 1];
    return scene || state.scenes[0];
  }, [state.scenes, currentTime]);

  useEffect(() => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;
    const lerp = (a: number, b: number, n: number) => (1 - n) * a + n * b;

    const render = () => {
      const W = 1280, H = 720;
      ctx.fillStyle = state.zakMode ? '#FFFFFF' : '#020617';
      ctx.fillRect(0, 0, W, H);

      if (activeScene && activeScene.assetUrl && imageCache.current.has(activeScene.assetUrl)) {
        const img = imageCache.current.get(activeScene.assetUrl)!;
        const sceneDur = activeScene.endTime - activeScene.startTime;
        const relTime = Math.max(0, currentTime - activeScene.startTime);
        const progress = Math.min(1, relTime / (sceneDur || 1));
        const drawProg = Math.min(1, relTime / (sceneDur * 0.4 || 1));

        const targetX = (activeScene.focalPoint?.x ?? 0.5) - 0.5;
        const targetY = (activeScene.focalPoint?.y ?? 0.5) - 0.5;
        let tZ = 1.05;
        if (activeScene.animationType === 'zoom-in') tZ = 1.0 + progress * 0.15;
        if (activeScene.animationType === 'zoom-out') tZ = 1.15 - progress * 0.15;

        cameraRef.current.x = lerp(cameraRef.current.x, targetX * -300, 0.08);
        cameraRef.current.y = lerp(cameraRef.current.y, targetY * -240, 0.08);
        cameraRef.current.z = lerp(cameraRef.current.z, tZ, 0.08);

        const dW = W * cameraRef.current.z, dH = H * cameraRef.current.z;
        const dx = (W - dW)/2 + cameraRef.current.x, dy = (H - dH)/2 + cameraRef.current.y;

        ctx.save();
        ctx.beginPath();
        const segs = 40;
        const sW = W / segs;
        for (let i = 0; i < segs; i++) {
          if ((i/segs) < drawProg) {
            const lP = Math.min(1, (drawProg - (i/segs)) * segs);
            ctx.rect(i * sW, 0, sW + 1, H * lP + Math.sin(currentTime * 15 + i) * 8);
          }
        }
        ctx.clip();
        ctx.drawImage(img, dx, dy, dW, dH);
        ctx.restore();

        if (handImageRef.current && drawProg < 1) {
          const hW = 320, hH = 320;
          const hx = (W * drawProg) - 160 + Math.sin(currentTime * 60) * 15;
          const hy = (H * Math.min(1, (drawProg % (1/segs)) * segs)) - 100 + Math.cos(currentTime * 55) * 15;
          ctx.save();
          ctx.translate(hx + hW/2, hy + hH/2);
          ctx.rotate(Math.sin(currentTime * 20) * 0.1);
          ctx.drawImage(handImageRef.current, -hW/2, -hH/2, hW, hH);
          ctx.restore();
        }
      }
      if (isPlaying || state.isRendering) requestAnimationFrame(render);
    };
    render();
  }, [activeScene, currentTime, isPlaying, state.isRendering, state.zakMode]);

  const handleDownload = async () => {
    if (!canvasRef.current || !audioRef.current || !musicRef.current) return;
    setState(s => ({ ...s, isRendering: true }));
    
    if (!audioContextRef.current) audioContextRef.current = new AudioContext();
    const ctx = audioContextRef.current;
    if (ctx.state === 'suspended') await ctx.resume();

    const dest = ctx.createMediaStreamDestination();
    
    // Voice Over
    const vSrc = ctx.createMediaElementSource(audioRef.current);
    const vGain = ctx.createGain();
    vGain.gain.value = 1.0;
    vSrc.connect(vGain).connect(dest);
    vSrc.connect(ctx.destination);

    // Background Music
    const mSrc = ctx.createMediaElementSource(musicRef.current);
    const mGain = ctx.createGain();
    mGain.gain.value = 0.15; // Much quieter than voice
    mSrc.connect(mGain).connect(dest);
    mSrc.connect(ctx.destination);

    const stream = new MediaStream([...canvasRef.current.captureStream(60).getTracks(), ...dest.stream.getTracks()]);
    const recorder = new MediaRecorder(stream, { mimeType: 'video/webm', videoBitsPerSecond: 30000000 });
    const chunks: Blob[] = [];

    recorder.ondataavailable = (e) => chunks.push(e.data);
    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `YouTube_Whiteboard_Master_${Date.now()}.webm`;
      a.click();
      setState(s => ({ ...s, isRendering: false }));
    };

    audioRef.current.currentTime = 0;
    musicRef.current.currentTime = 0;
    setCurrentTime(0);
    setIsPlaying(true);
    recorder.start();
    audioRef.current.play();
    musicRef.current.play();

    const check = setInterval(() => {
      if (audioRef.current?.ended) {
        recorder.stop();
        musicRef.current?.pause();
        setIsPlaying(false);
        clearInterval(check);
      }
      if (audioRef.current) {
        setState(s => ({ ...s, renderProgress: Math.round((audioRef.current!.currentTime / audioRef.current!.duration) * 100) }));
      }
    }, 100);
  };

  const formatTime = (s: number) => `${Math.floor(s/60)}:${Math.floor(s%60).toString().padStart(2, '0')}`;

  return (
    <div className="min-h-screen bg-[#020617] text-white flex flex-col">
      <nav className="border-b border-white/5 bg-slate-950/60 backdrop-blur-2xl p-6 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-5">
            <div className="p-3 bg-teal-600 rounded-2xl shadow-lg shadow-teal-600/20">
              <HandRaisedIcon className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-black uppercase italic tracking-tighter">Zak<span className="text-teal-400">Production</span> AI</h1>
          </div>
          {state.appStage === 'production' && (
            <button onClick={() => setState(s => ({ ...s, appStage: 'input' }))} className="text-xs font-bold uppercase text-slate-500 hover:text-white transition-colors">Start New Project</button>
          )}
        </div>
      </nav>

      <main className="flex-1 p-6 lg:p-12 max-w-7xl mx-auto w-full">
        <AnimatePresence mode="wait">
          {state.appStage === 'input' && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="max-w-3xl mx-auto space-y-12 py-20">
              <div className="text-center space-y-4">
                <h2 className="text-5xl font-black uppercase tracking-tighter italic">Generate Your <span className="text-teal-400">Legacy</span></h2>
                <p className="text-slate-400 font-medium">One click to convert any topic into a professional 10-20 min whiteboard video.</p>
              </div>
              <div className="bg-slate-900/30 border border-white/10 rounded-[3rem] p-10 space-y-8 backdrop-blur-3xl shadow-2xl">
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest italic">Video Topic or Theme</label>
                  <input 
                    type="text" 
                    placeholder="e.g. The Psychology of Financial Freedom..." 
                    value={state.topic}
                    onChange={e => setState(s => ({ ...s, topic: e.target.value }))}
                    className="w-full bg-slate-950/50 border border-white/10 rounded-2xl p-6 text-lg font-bold outline-none ring-teal-500/30 focus:ring-4 transition-all"
                  />
                </div>
                <button 
                  onClick={handleGenerateScript}
                  disabled={state.isGeneratingScript || !state.topic}
                  className="w-full py-6 bg-teal-600 hover:bg-teal-500 disabled:opacity-20 rounded-2xl font-black text-lg uppercase transition-all shadow-xl flex items-center justify-center gap-4"
                >
                  {state.isGeneratingScript ? <ArrowPathIcon className="w-6 h-6 animate-spin" /> : <SparklesIcon className="w-6 h-6" />}
                  {state.isGeneratingScript ? 'Crafting Script...' : 'Generate AI Script'}
                </button>
              </div>
            </motion.div>
          )}

          {state.appStage === 'script' && (
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="space-y-10">
              <div className="flex justify-between items-end">
                <div className="space-y-2">
                  <h3 className="text-4xl font-black uppercase italic tracking-tighter">Review & <span className="text-teal-400">Approve</span></h3>
                  <p className="text-slate-400">Edit your script below. Once ready, Zak will build the full visual package.</p>
                </div>
                <button 
                  onClick={handleStartProduction}
                  className="px-12 py-6 bg-emerald-600 hover:bg-emerald-500 rounded-3xl font-black text-lg uppercase shadow-2xl flex items-center gap-4 active:scale-95 transition-all"
                >
                  Next: Start Production
                  <ChevronRightIcon className="w-6 h-6" />
                </button>
              </div>
              <div className="bg-slate-900/30 border border-white/10 rounded-[3rem] p-10 backdrop-blur-3xl shadow-inner h-[600px] flex flex-col">
                <textarea 
                  value={state.scriptText}
                  onChange={e => setState(s => ({ ...s, scriptText: e.target.value }))}
                  className="flex-1 bg-transparent border-none outline-none resize-none font-medium leading-relaxed text-slate-200 text-lg scrollbar-hide"
                />
              </div>
            </motion.div>
          )}

          {state.appStage === 'production' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid lg:grid-cols-12 gap-10">
              <div className="lg:col-span-8 space-y-10">
                <div className={`aspect-video rounded-[3rem] border border-white/10 overflow-hidden shadow-2xl relative ${state.zakMode ? 'bg-white' : 'bg-black'}`}>
                  <canvas ref={canvasRef} width={1280} height={720} className="w-full h-full object-contain cursor-pointer" onClick={() => { if (isPlaying) { audioRef.current?.pause(); musicRef.current?.pause(); } else { audioRef.current?.play(); musicRef.current?.play(); } setIsPlaying(!isPlaying); }} />
                  <audio ref={audioRef} onTimeUpdate={e => setCurrentTime(e.currentTarget.currentTime)} onEnded={() => setIsPlaying(false)} />
                  <audio ref={musicRef} src={BG_MUSIC_URL} loop />
                  
                  <AnimatePresence>
                    {state.isProcessing && (
                      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-slate-950/90 backdrop-blur-3xl flex flex-col items-center justify-center z-30">
                        <ArrowPathIcon className="w-24 h-24 animate-spin text-teal-400 opacity-20 mb-8" />
                        <h4 className="text-2xl font-black uppercase italic">Creating Your Full Production</h4>
                        <div className="mt-6 flex gap-8 text-slate-400 font-mono text-sm">
                          <span>Elapsed: {formatTime(elapsedTime)}</span>
                          <span className="text-teal-400">ETA: ~{formatTime(eta || 0)}</span>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <section className="bg-slate-900/30 border border-white/10 rounded-[3rem] p-10 space-y-8 backdrop-blur-3xl">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-4">
                      <ClockIcon className="w-6 h-6 text-teal-400" />
                      <span className="text-xl font-mono tabular-nums">{formatTime(currentTime)} / {formatTime(audioRef.current?.duration || 0)}</span>
                    </div>
                    <div className="flex gap-4">
                      <div className="flex items-center gap-2 px-6 py-3 bg-slate-950 rounded-full border border-white/5 text-[10px] font-black uppercase text-teal-400">
                        <MusicalNoteIcon className="w-4 h-4" /> Mixed Audio
                      </div>
                      <button onClick={handleDownload} disabled={state.isRendering || state.isProcessing} className="px-8 py-4 bg-teal-600 rounded-2xl font-black uppercase shadow-xl flex items-center gap-3">
                        {state.isRendering ? `Encoding ${state.renderProgress}%` : <><ArrowDownTrayIcon className="w-5 h-5" /> Export Master</>}
                      </button>
                    </div>
                  </div>
                  <div className="h-40 bg-slate-950/80 rounded-[2rem] border border-white/5 flex p-4 gap-4 overflow-x-auto scrollbar-hide relative">
                    {state.scenes.map((scene, i) => (
                      <div key={scene.id} className={`h-full flex-shrink-0 rounded-2xl border transition-all ${activeScene?.id === scene.id ? 'border-teal-400 w-64 bg-teal-900/10' : 'border-white/5 w-40 opacity-40'}`}>
                        {scene.assetUrl && <img src={scene.assetUrl} className="absolute inset-0 w-full h-full object-cover opacity-20" />}
                        <div className="relative z-10 p-5 h-full flex flex-col justify-between">
                          <span className="text-[10px] font-black uppercase truncate">{scene.keyword}</span>
                          <span className="text-[9px] font-mono text-slate-600">SEQ 0{i+1}</span>
                        </div>
                      </div>
                    ))}
                    <div className="absolute top-0 bottom-0 w-1 bg-teal-500 shadow-[0_0_20px_#14b8a6]" style={{ left: `${(currentTime / (audioRef.current?.duration || 1)) * 100}%` }} />
                  </div>
                </section>
              </div>

              <div className="lg:col-span-4 space-y-6">
                 <section className="bg-slate-900/30 border border-white/10 rounded-[2.5rem] p-8 space-y-6">
                    <h5 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500">Live Status</h5>
                    <div className="space-y-3">
                        {state.steps.map(s => (
                          <div key={s.id} className="flex items-center gap-4 bg-slate-950/40 p-4 rounded-2xl border border-white/5">
                            <div className={`w-2 h-2 rounded-full ${s.status === 'complete' ? 'bg-teal-500 shadow-[0_0_10px_#14b8a6]' : s.status === 'loading' ? 'bg-amber-500 animate-pulse' : 'bg-slate-700'}`} />
                            <span className="text-xs font-bold uppercase tracking-tighter">{s.label}</span>
                          </div>
                        ))}
                    </div>
                 </section>
                 <section className="bg-slate-900/30 border border-white/10 rounded-[2.5rem] p-8 space-y-6">
                    <h5 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500">Current Scene</h5>
                    <div className="space-y-4">
                      <p className="text-sm font-medium italic text-slate-300 leading-relaxed">"{activeScene?.text}"</p>
                      <div className="p-4 bg-teal-600/10 border border-teal-500/20 rounded-xl">
                        <span className="text-[9px] font-black uppercase text-teal-400 tracking-widest">Zak Prompt:</span>
                        <p className="text-[10px] text-slate-400 mt-2">{activeScene?.prompt}</p>
                      </div>
                    </div>
                 </section>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};

export default App;
