
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Scene, VoicePersona, VoiceGender, VisualStyle } from "../types";

export async function generateScript(topic: string): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `
    Act as a Master Storyteller and Educator. Generate a deep, engaging video script about: "${topic}".
    
    LENGTH REQUIREMENT: The script must be extremely detailed, aiming for a 10-20 minute spoken duration (approx 1500-3000 words).
    
    TONE & STYLE:
    - Simple language, no jargon.
    - Real-life examples and relatable situations.
    - Natural humor at light moments.
    - Inspiring and empowering.
    - HUMAN and real, not robotic.
    
    STRUCTURE:
    1. POWERFUL HOOK: Why this matters now.
    2. PREVIEW: What the viewer will learn.
    3. STEP-BY-STEP CONTENT: Detailed explanation with examples.
    4. MINI-STORY: A personal example or parable to build trust.
    5. FRAMEWORKS: Break concepts into lists or simple rules.
    6. ACTIONABLE STEPS: Practical things to do TODAY.
    7. MOTIVATION: A section to inspire confidence.
    8. SUMMARY: Recapping key lessons.
    9. CALL TO ACTION: Friendly invitation for interaction.
    
    Format the output as a clean text script ready for voiceover.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
  });

  return response.text;
}

export async function analyzeScript(
  script?: string, 
  audioBase64?: string, 
  audioMimeType?: string,
  duration?: number,
  zakMode: boolean = true
): Promise<Scene[]> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const parts: any[] = [];
  if (script) parts.push({ text: `Full Script: ${script}` });
  if (audioBase64) parts.push({ inlineData: { data: audioBase64, mimeType: audioMimeType } });
  
  const promptText = `
    Task: Act as a World-Class Video Director. Segment this script for a high-budget YouTube Whiteboard Video.
    Total Duration: ${duration ? duration.toFixed(1) : 'flexible'}s.
    
    CINEMATIC RULES:
    1. ZERO GAPS: Every millisecond from 0.0 to ${duration ? duration.toFixed(1) : 'end'} must be covered by a scene.
    2. SCENE LENGTH: Keep scenes between 4-7 seconds.
    3. FOCAL POINTS: Choose logical {x, y} for camera gliding.
    4. ZAK CHARACTER: Use Zak (Male, buzz cut, teal hoodie) in prompts as a physical metaphor for the spoken words.
    
    Return JSON array of scenes.
  `;
  parts.push({ text: promptText });

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: { parts },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            text: { type: Type.STRING },
            startTime: { type: Type.NUMBER },
            endTime: { type: Type.NUMBER },
            keyword: { type: Type.STRING },
            animationType: { type: Type.STRING },
            prompt: { type: Type.STRING },
            focalPoint: {
              type: Type.OBJECT,
              properties: {
                x: { type: Type.NUMBER },
                y: { type: Type.NUMBER }
              },
              required: ["x", "y"]
            }
          },
          required: ["text", "startTime", "endTime", "keyword", "prompt", "animationType", "focalPoint"]
        }
      }
    }
  });

  const rawScenes = JSON.parse(response.text);
  return rawScenes.map((s: any, i: number) => ({
    ...s,
    id: `scene-${i}`,
    style: zakMode ? 'zak-invest' : 'blueprint-curator'
  }));
}

export async function generateTTS(text: string, gender: VoiceGender, speed: number = 1.0, zakMode: boolean = false): Promise<{ base64: string, sampleRate: number }> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const voiceName = zakMode ? 'Charon' : (gender === 'male' ? 'Fenrir' : 'Kore');
  
  const instruction = zakMode 
    ? `Zak Invest: Expert Educator. Resonant, warm male voice. Professional pacing. Pace: ${speed.toFixed(1)}x.`
    : `Professional narrator. Natural and engaging. Pace: ${speed.toFixed(1)}x.`;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `${instruction}: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName },
        },
      },
    },
  });

  const base64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64) throw new Error("TTS Generation failed");
  return { base64, sampleRate: 24000 };
}

export async function generateImageForScene(
  scenePrompt: string, 
  characterImageBase64?: string,
  style: VisualStyle = 'zak-invest'
): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const isZak = style === 'zak-invest';
  
  const styleContext = isZak 
    ? "STYLE: Professional YouTube Whiteboard Art. Pure #FFFFFF white background. Thick black marker line art. Vibrantly colored teal hoodie on character. High-end professional doodle. NO text."
    : "STYLE: Minimalist Blueprint art.";

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: { parts: [{ text: `SCENE: ${scenePrompt}. ${styleContext}` }] },
    config: { imageConfig: { aspectRatio: "16:9" } }
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  throw new Error("Visual generation failed");
}
